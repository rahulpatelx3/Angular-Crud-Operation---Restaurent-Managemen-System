export class RestaurentModel {
    id:number=0;
    name:string ='';
    email:string ='';
    mobile:string ='';
    address:string ='';
    services:string ='';
}