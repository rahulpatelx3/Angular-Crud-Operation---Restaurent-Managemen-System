package com.restaurent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestaurentAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestaurentAppApplication.class, args);
	}

}
