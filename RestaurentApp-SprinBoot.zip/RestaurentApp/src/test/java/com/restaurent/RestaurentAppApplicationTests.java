package com.restaurent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestaurentAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
